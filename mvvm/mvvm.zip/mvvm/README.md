# MVVM

MVVM(Model-View-ViewModel) 是一种数据绑定式的Android app架构。

![mvvm](./mvvm.png)


项目结构采用mvvm架构+组件化，组件化采用alibaba的组件化库ARouter实现。





### 项目模块

#### BaseLibrary
基本功能模块，存放基本的工具类、静态资源等。